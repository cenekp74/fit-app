Credits
=======

``symfit`` is written and maintained by Martin Roelfs.


Contributors
------------

The following wonderful people contributed directly or indirectly to this project:

- Peter C Kroon (@pckroon)

Please add yourself here alphabetically when you submit your first pull request.
